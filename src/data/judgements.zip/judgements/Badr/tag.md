CA016690
Vancouver Registry
__Court of Appeal for British Columbia__
BETWEEN:
__233467 B.C. LTD.__
PLAINTIFF
(APPELLANT)
AND:
__MONTREAL TRUST COMPANY OF CANADA__
DEFENDANT
(RESPONDENT)
Before: __The Honourable Mr. Justice Hutcheon__
__The Honourable Mr. Justice Legg__
The Honourable Mr. Justice Finch
M. P.O'Neill Counsel for the Appellant
J. F. Grieve Counsel for the Respondent
Place and Date of Hearing: Vancouver, British Columbia
January 21, 1994
Place and Date of Judgment: Vancouver, British Columbia
February 1, 1994
Written Reasons by
:
The Honourable Mr. Justice Hutcheon
Concurred in by
:
The Honourable Mr. Justice Legg
The Honourable Mr. Justice Finch
No. CA016690
Vancouver Registry

Court of Appeal for British Columbia
233467 B.C. Ltd.
v.
Montreal Trust Company of Canada
REASONS FOR JUDGMENT OF
THE HONOURABLE MR. JUSTICE HUTCHEON
1. At the end of the hearing of the appeal we dismissed the appeal with written reasons to follow. These are those reasons.
2. In January 1985 the appellant, 233467 B.C. Ltd., borrowed money from the respondent, Montreal Trust Company of Canada Ltd., and as security for the loan of $614,000 granted a mortgage to Montreal Trust to mature in five years. At the end of the five year period, Montreal Trust, in February 1990, extended the mortgage for a further period of four years. In the extension agreement, the borrower did not have the right to prepay the principal. The issue in this appeal is whether during the term of the extension the borrower could compel Montreal Trust to grant a discharge of the mortgage upon payment of the principal and three months interest.
3. The borrower claimed the right to do this under s.10(1) of the
Interest Act
but Mr. Justice Collver held that the section did not apply, firstly, because the borrower was a corporation and secondly, because the term of the mortgage had not exceeded five years. Section 10(1) cannot be invoked "until a time more than five years after the date of the mortgage" and, by section 10(2), the section does not apply "to any mortgage upon real estate given by a joint stock company."
4. Briefly stated, the facts are that in 1992 the borrower had arranged to sell its condominium project and needed clear title to complete the sale. Montreal Trust advised that it would accept prepayment of principal and grant a discharge of the mortgage on receipt of the principal then owing plus $55,000. By letter dated June 26, 1992, the borrower insisted that under s.10(1) of the
Interest Act
it was entitled to a discharge upon the payment of the principal plus three months interest, or approximately $18,000. It was prepared to pay a bit more than $18,000 as a matter of goodwill. Montreal Trust did not agree.
5. On 3 July 1992 the borrower caused to be deposited $594,352.58, that is the principal, plus three months interest and miscellaneous charges, in the appropriate account at Montreal Trust. When Montreal Trust refused to deliver a discharge of the mortgage, the borrower, on 28 July 1992, filed a petition in the Supreme Court for a declaration that the mortgage had been paid off and discharged. On the first hearing of the petition on 27 August 1992, the judge ordered that upon payment by the borrower of $42,000 into the trust account of the solicitors for Montreal Trust the mortgage be discharged. He further ordered that written argument be filed to determine the entitlement to the $42,000. The borrower made the payment and the mortgage was discharged.
The
Interest Act
s.10
(1) Whenever any principal money or interest secured by mortgage on real property is not, under the terms of the mortgage, payable until a time more than five years after the date of the mortgage, then, if at any time after the expiration of the five years, any person liable to pay or entitled to redeem the mortgage tenders or pays, to the person entitled to receive the money, the amount due for principal money and interest to the time of payment, as calculated under sections 6 to 9, together with three months further interest in lieu of notice, no further interest shall be chargeable, payable or recoverable at any time thereafter on the principal money or interest due under the mortgage.
(2) Nothing in this section applies to any mortgage on real property given by a joint stock company or other corporation, nor to any debenture issued by any such company or corporation, for the payment of which security has been given by way of mortgage on real property, R.S., c.I-18 , s.10.
6. The judge held that the mortgage remained one given by a corporation and thus subject to s.10(2) notwithstanding the involvement of the principals of the company as covenantors. He also held that by reason of the decision of the Supreme Court of Canada in
Potash v. Royal Trust
, [1986] 6 W.W.R. 550 (S.C.C.), s.10(1) is intended to permit the mortgagor to pay the mortgage off at the end of each five-year renewal period. Thus even though the mortgage was in its eighth year, the renewal period was only in its third year.
7. For the reasons given by the chambers judge I agree that s.10(1) of the
Interest Act
has no application to the facts of this case.
The Position On Appeal
8. Mr. O'Neill, counsel for the appellant on the appeal, sought to persuade us that Montreal Trust had no right to elect to retain the payment of principal and interest and then to demand additional moneys. He also submitted in the alternative that it would be unjust enrichment if Montreal Trust recovered a return on investment greater than the interest revenue contemplated by the mortgage.
9. The first submission overlooks the course of the proceedings initiated and followed by the borrower. The second fails to take account of the legal position of Montreal Trust confirmed by the chambers judge.
10. The legal position was that, because s.10(1) of the
Interest Act
did not apply, Montreal Trust was entitled to require the borrower to comply with the terms of the mortgage for the balance of the four year extension period. No law was available to compel Montreal Trust to terminate its contract with the borrower at an earlier date. The chambers judge found that the amount demanded by Montreal Trust to do so was simply the price fixed to vary the extension agreement. 
11. I think that to be exactly right. Further, the borrower was not compelled by any law to pay that price and it did so for its own benefit to complete the sale of the project.
12. To obtain a discharge of the mortgage the borrower filed a petition in the Supreme Court for a remedy under s.10(1) of the
Interest Act
. No one has mentioned that s.10(1) does not provide for the remedy of a discharge of the mortgage. It may be that such a remedy is beyond the legislative competence of the Parliament of Canada. Whatever the explanation, s.10(1) has no reference to a discharge of the mortgage or to the state of the title after payment.
13. In filing the petition the borrower was not seeking the return of its money; its objective was the discharge of the mortgage essential to the completion of the sale. When the judge made the order on 27 August 1992, the borrower followed the course proposed by the judge to achieve that end by making the payment of $42,000. It could have decided not to make the payment and called for the repayment of the principal. Having elected to initiate and follow the course of proceedings that it did, the borrower cannot complain that Montreal Trust, although not legally obliged to do so, agreed to participate on the terms set out in the order.
These are the reasons that caused us to dismiss the appeal.

"The Honourable Mr. Justice Hutcheon"
I agree: "The Honourable Mr. Justice Legg"
I agree: "The Honourable Mr. Justice Finch"